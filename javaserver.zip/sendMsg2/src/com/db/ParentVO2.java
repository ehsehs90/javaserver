package com.db;

import java.util.Date;

public class ParentVO2 {

    String memberID = null;
    String memberPW = null;
    String memberName = null;
    String memberTel = null;
    String memberinfo = null;
    Date registerDate = null;

    public ParentVO2() {
    }

    public ParentVO2(String memberID, String memberPW, String memberName, String memberTel, String memberinfo, Date registerDate) {
        this.memberID = memberID;
        this.memberPW = memberPW;
        this.memberName = memberName;
        this.memberTel = memberTel;
        this.memberinfo = memberinfo;
        this.registerDate = registerDate;
    }

    @Override
    public String toString() {
        return "BaseVO{" +
                "memberID='" + memberID + '\'' +
                ", memberPW='" + memberPW + '\'' +
                ", memberNum='" + memberName + '\'' +
                ", memberTel='" + memberTel + '\'' +
                ", memberinfo='" + memberinfo + '\'' +
                ", registerDate=" + registerDate +
                '}';
    }

    public String getMemberID() {
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public String getMemberPW() {
        return memberPW;
    }

    public void setMemberPW(String memberPW) {
        this.memberPW = memberPW;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberTel() {
        return memberTel;
    }

    public void setMemberTel(String memberTel) {
        this.memberTel = memberTel;
    }

    public String getMemberinfo() {
        return memberinfo;
    }

    public void setMemberinfo(String memberinfo) {
        this.memberinfo = memberinfo;
    }

    public Date getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(Date registerDate) {
        this.registerDate = registerDate;
    }
}