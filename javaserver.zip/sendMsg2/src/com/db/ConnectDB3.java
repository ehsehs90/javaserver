package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnectDB3 {

	private static ConnectDB3 instance = new ConnectDB3();

	public static ConnectDB3 getInstance() {
		return instance;
	}

	public ConnectDB3() {
	}

	Connection conn = null;

	public static Connection getConnection() {

		// oracle ����
		String jdbcUrl = "jdbc:oracle:thin:@70.12.115.51:1521:xe";
		String userId = "scott";
		String userPw = "TIGER";
		Connection conn = null;

		try {
			Class.forName("oracle.jdbc.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			conn = DriverManager.getConnection(jdbcUrl, userId, userPw);
			// System.out.println("���Ἲ��, ȣ�⼺��");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;
	}

	
	//학부모
	public String register(BaseVO base) throws SQLException {

		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs = null;
		String returns = "aaaaa";

		try {
			String sql = "SELECT ID FROM BASE WHERE ID = ?"; // APPUSERINFO
			pstmt = getConnection().prepareStatement(sql);
			pstmt.setString(1, base.getMemberID());

			rs = pstmt.executeQuery();

			System.out.println("id는 ? : @" + base.getMemberID());
			System.out.println("pw는 ? : @" + base.getMemberPW());
			System.out.println("name는 ? : @" + base.getMemberName());
			System.out.println("tel는 ? : @" + base.getMemberTel());

			if (base.getMemberID() == null || base.getMemberID().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = " 회원 가입 실패! 아이디에 값을 입력해 주세요.";
			} else if (base.getMemberPW() == null || base.getMemberPW().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = " 회원 가입 실패! 패스워드에 값을 입력해 주세요.";
			} else if (base.getMemberName() == null || base.getMemberName().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = " 회원 가입 실패! 숫자에 값을 입력해 주세요.";
			} else if (base.getMemberTel() == null || base.getMemberTel().isEmpty() == true) {
					// System.out.println("dddddd");
					returns = " 회원 가입 실패! 이름에 값을 입력해 주세요.";
				}else {
				if (rs.next()) {
					returns = "이미 존재하는아이디입니다";
				} else {
					String sql2 = "INSERT INTO BASE VALUES(?,?,?,?)";
					pstmt2 = getConnection().prepareStatement(sql2);
					pstmt2.setString(1, base.getMemberID());
					pstmt2.setString(2, base.getMemberPW());
					pstmt2.setString(3, base.getMemberName());
					pstmt2.setString(4, base.getMemberTel());
					pstmt2.executeUpdate();
					returns = "회원가입성공 !";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt2 != null)
				try {
					pstmt2.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (getConnection() != null)
				try {
					getConnection().close();
				} catch (SQLException ex) {
				}
		}

		return returns;
	}
	
	
	//운전자
	public String register2(BaseVO base) throws SQLException {

		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs = null;
		String returns = "aaaaa";

		try {
			String sql = "SELECT ID FROM BASE WHERE ID = ?"; // APPUSERINFO
			pstmt = getConnection().prepareStatement(sql);
			pstmt.setString(1, base.getMemberID());

			rs = pstmt.executeQuery();

			System.out.println("id는 ? : @" + base.getMemberID());
			System.out.println("pw는 ? : @" + base.getMemberPW());
			System.out.println("name는 ? : @" + base.getMemberName());
			System.out.println("tel는 ? : @" + base.getMemberTel());

			if (base.getMemberID() == null || base.getMemberID().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = "회원가입실패 아이디입력바람.";
			} else if (base.getMemberPW() == null || base.getMemberPW().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = "회원가입실패 패스워드 입력바람.";
			} else if (base.getMemberName() == null || base.getMemberName().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = "회원가입실패 이름 입력바람.";
			} else {
				if (rs.next()) {
					returns = "이미 존재하는아이디입니다";
				} else {
					String sql2 = "INSERT INTO BASE VALUES(?,?,?,?)";
					pstmt2 = getConnection().prepareStatement(sql2);
					pstmt2.setString(1, base.getMemberID());
					pstmt2.setString(2, base.getMemberPW());
					pstmt2.setString(3, base.getMemberName());
					pstmt2.setString(4, base.getMemberTel());
					pstmt2.executeUpdate();
					returns = "회원가입성공 !";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt2 != null)
				try {
					pstmt2.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (getConnection() != null)
				try {
					getConnection().close();
				} catch (SQLException ex) {
				}
		}

		return returns;
	}

	//보육교사
	public String register3(BaseVO base) throws SQLException {

		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs = null;
		String returns = "aaaaa";

		try {
			String sql = "SELECT ID FROM BASE WHERE ID = ?"; // APPUSERINFO
			pstmt = getConnection().prepareStatement(sql);
			pstmt.setString(1, base.getMemberID());

			rs = pstmt.executeQuery();

			System.out.println("id는 ? : @" + base.getMemberID());
			System.out.println("pw는 ? : @" + base.getMemberPW());
			System.out.println("name는 ? : @" + base.getMemberName());
			System.out.println("tel는 ? : @" + base.getMemberTel());

			if (base.getMemberID() == null || base.getMemberID().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = "회원가입실패 아이디입력바람.";
			} else if (base.getMemberPW() == null || base.getMemberPW().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = "회원가입실패 패스워드 입력바람.";
			} else if (base.getMemberName() == null || base.getMemberName().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = "회원가입실패 이름 입력바람.";
			} else {
				if (rs.next()) {
					returns = "이미 존재하는아이디입니다";
				} else {
					String sql2 = "INSERT INTO BASE VALUES(?,?,?,?)";
					pstmt2 = getConnection().prepareStatement(sql2);
					pstmt2.setString(1, base.getMemberID());
					pstmt2.setString(2, base.getMemberPW());
					pstmt2.setString(3, base.getMemberName());
					pstmt2.setString(4, base.getMemberTel());
					pstmt2.executeUpdate();
					returns = "회원가입성공 !";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt2 != null)
				try {
					pstmt2.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (getConnection() != null)
				try {
					getConnection().close();
				} catch (SQLException ex) {
				}
		}

		return returns;
	}
	public void msg(BaseVO base) throws SQLException {

	}
}