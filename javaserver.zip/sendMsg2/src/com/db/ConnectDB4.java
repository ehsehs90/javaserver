//package com.db;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//public class ConnectDB4 {
//
//	int flag = 0;
//
//	private static ConnectDB4 instance = new ConnectDB4();
//
//	public static ConnectDB4 getInstance() {
//		return instance;
//	}
//
//	public ConnectDB4() {
//	}
//
//	Connection conn = null;
//
//	public static Connection getConnection() {
//
//		// oracle 계정
//		String jdbcUrl = "jdbc:oracle:thin:@70.12.115.54:1521:xe";
//		String userId = "SCOTT";
//		String userPw = "TIGER";
//		Connection conn = null;
//
//		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//		} catch (ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		try {
//			conn = DriverManager.getConnection(jdbcUrl, userId, userPw);
//			// System.out.println("연결성공, 호출성공");
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		return conn;
//	}
//
//	// base
//	public String register(BaseVO base) throws SQLException {
//
//		PreparedStatement pstmt = null;
//		PreparedStatement pstmt2 = null;
//		ResultSet rs = null;
//
//		String returns = null;
//
//		try {
//			String sql = "SELECT ID FROM BASE WHERE ID = ?"; // APPUSERINFO
//			pstmt = getConnection().prepareStatement(sql);
//			pstmt.setString(1, base.getMemberID());
//
//			rs = pstmt.executeQuery();
//
//			System.out.println("id는 ? : @" + base.getMemberID());
//			System.out.println("pw는 ? : @" + base.getMemberPW());
//			System.out.println("name는 ? : @" + base.getMemberName());
//			System.out.println("tel는 ? : @" + base.getMemberTel());
//			System.out.println("date는 ? : @" + base.getRegisterDate());
//			System.out.println("info는? : @" + base.getMemberinfo());
//
//			if (base.getMemberID() == null || base.getMemberID().isEmpty() == true) {
//				// System.out.println("dddddd");
//				returns = "회원 가입 실패! 아이디에 값을 입력해 주세요.";
//			} else if (base.getMemberPW() == null || base.getMemberPW().isEmpty() == true) {
//				// System.out.println("dddddd");
//				returns = "회원 가입 실패! 비밀번호에 값을 입력해 주세요.";
//			} else if (base.getMemberName() == null || base.getMemberName().isEmpty() == true) {
//				// System.out.println("dddddd");
//				returns = "회원 가입 실패! 이름에 값을 입력해 주세요.";
//			} else {
//				if (rs.next()) {
//					returns = "이미 존재하는 아이디 입니다.";
//				} else {
//
//					returns = "직업군을선택하세요";
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			if (pstmt2 != null)
//				try {
//					pstmt2.close();
//				} catch (SQLException ex) {
//				}
//			if (pstmt != null)
//				try {
//					pstmt.close();
//				} catch (SQLException ex) {
//				}
//			if (getConnection() != null)
//				try {
//					getConnection().close();
//				} catch (SQLException ex) {
//				}
//		}
//
//		return returns;
//	}
//
//	// 보육교사
//	public String register교사 (BaseVO base) throws SQLException {
// 
//       PreparedStatement pstmt = null;
//       PreparedStatement pstmt2 = null;
//       ResultSet rs = null;
//
//       String returns = null;
//      
//         try {
//           
//                
//                  String sql2 = "INSERT INTO BASE VALUES(?,?,?,?)";
//                  pstmt2 = getConnection().prepareStatement(sql2);
//                  pstmt2.setString(1, base.getMemberID());
//                  pstmt2.setString(2, base.getMemberPW());
//                  pstmt2.setString(3, base.getMemberName());
//                  pstmt2.setString(4, base.getMemberTel());
//                  pstmt2.executeUpdate();
//                  flag = 0;
//                  returns = "회원 가입 성공 !";
//               }
//            }returns;
//
//}
//
//	}
//
//	public String registerdriver(DriverVO dv) throws SQLException {
//
//		PreparedStatement pstmt2 = null, pstmt = null;
//		ResultSet rs = null;
//
//		String returns = null;
//		// System.out.println(returns);
//
//		if (flag == 0) {
//			try {
//
//				// 혁진이 왜 이거 업승?이거없으니까 rs.next()가 null값되는거 아님?
//				String sql = "SELECT ID FROM BASE WHERE ID = ?"; // APPUSERINFO
//				pstmt = getConnection().prepareStatement(sql);
//				pstmt.setString(1, dv.getDriverLicense());
//
//				rs = pstmt.executeQuery();
//
//				System.out.println("운전면허번호는 ? : @" + dv.getDriverLicense());
//				System.out.println("차량번호는 ? : @" + dv.getCarNumber());
//				System.out.println("운전자와꾸는 ? : @" + dv.getDriverPicture());
//
//				if (dv.getDriverLicense() == null || dv.getDriverLicense().isEmpty() == true) {
//					// System.out.println("dddddd");
//					returns = "회원 가입 실패! 면허증에 값을 입력해 주세요.";
//				} else if (dv.getCarNumber() == null || dv.getCarNumber().isEmpty() == true) {
//					// System.out.println("dddddd");
//					returns = "회원 가입 실패! 차번호에 값을 입력해 주세요.";
//				} else {
//					// System.out.println("여기인가봐요....driver");
//					if (rs.next()) {
//						returns = "이미 존재하는 값 입니다.";
//						// System.out.println("이미존재..?ㅇㅅㅇ?driver");
//					} else {
//						// System.out.println("여기에요!driver");
//
//						String sql2 = "INSERT INTO 회원정보 VALUES(?,?,?,?)";
//						pstmt2 = getConnection().prepareStatement(sql2);
//						pstmt2.setString(1, base.getMemberID());
//						pstmt2.setString(2, base.getMemberPW());
//						pstmt2.setString(3, base.getMemberName());
//						pstmt2.setString(4, base.getMemberTel());
//						pstmt2.executeUpdate();
//						flag = 0;
//
//						String sql2 = "INSERT INTO 드라이버 (ID,PW,NAME) VALUES(?,?,?)";
//						pstmt2 = getConnection().prepareStatement(sql2);
//						pstmt2.setString(1, dv.getDriverLicense());
//						pstmt2.setString(2, dv.getCarNumber());
//						pstmt2.setString(3, dv.getDriverPicture());
//
//						pstmt2.executeUpdate();
//						returns = "회원 가입 성공 !";
//					}
//				}
//			} catch (Exception e) {
//				e.printStackTrace();
//			} finally {
//				if (pstmt2 != null)
//					try {
//						pstmt2.close();
//					} catch (SQLException ex) {
//					}
//				if (getConnection() != null)
//					try {
//						getConnection().close();
//					} catch (SQLException ex) {
//					}
//			}
//		} else
//			returns = "메롱드라이버";
//
//		return returns;
//	}
//
//	public String registerparents(ParentsVO pv) throws SQLException {
//
//		PreparedStatement pstmt2 = null, pstmt = null;
//		ResultSet rs = null;
//
//		String returns = null;
//		// System.out.println(returns);
//
//		if (flag == 0) {
//			try {
//
//				// 혁진이 왜 이거 업승?이거없으니까 rs.next()가 null값되는거 아님?
//				String sql = "SELECT ID FROM BASE WHERE ID = ?"; // APPUSERINFO
//				pstmt = getConnection().prepareStatement(sql);
//				pstmt.setString(1, pv.getbabyName());
//
//				rs = pstmt.executeQuery();
//
//				System.out.println("아기이름은 ? : @" + pv.getbabyName());
//				System.out.println("아기성별은 ? : @" + pv.getbabyGender());
//				System.out.println("주소는 ? : @" + pv.getaddress());
//				System.out.println("노선은 ? : @" + pv.getstation());
//
//				if (pv.getbabyName() == null || pv.getbabyName().isEmpty() == true) {
//					// System.out.println("dddddd");
//					returns = "회원 가입 실패! 아기이름에 값을 입력해 주세요.";
//				} else if (pv.getbabyGender() == null || pv.getbabyGender().isEmpty() == true) {
//					// System.out.println("dddddd");
//					returns = "회원 가입 실패! 아기성별에 값을 입력해 주세요.";
//				} else if (pv.getaddress() == null || pv.getaddress().isEmpty() == true) {
//					// System.out.println("dddddd");
//					returns = "회원 가입 실패! 주소에 값을 입력해 주세요.";
//				} else if (pv.getstation() == null || pv.getstation().isEmpty() == true) {
//					// System.out.println("dddddd");
//					returns = "회원 가입 실패! 노선에 값을 입력해 주세요.";
//				} else {
//					// System.out.println("여기인가봐요....");
//					if (rs.next()) {
//						returns = "이미 존재하는 아기 입니다.";
//						// System.out.println("이미존재..?ㅇㅅㅇ?");
//					} else {
//						// System.out.println("여기에요!");
//						
//
//						String sql2 = "INSERT INTO 회원정보 VALUES(?,?,?,?)";
//						pstmt2 = getConnection().prepareStatement(sql2);
//						pstmt2.setString(1, base.getMemberID());
//						pstmt2.setString(2, base.getMemberPW());
//						pstmt2.setString(3, base.getMemberName());
//						pstmt2.setString(4, base.getMemberTel());
//						pstmt2.executeUpdate();
//						flag = 0;
//						
//						String sql2 = "INSERT INTO 학부모테이블 VALUES(?,?,?,?)";
//						pstmt2 = getConnection().prepareStatement(sql2);
//						pstmt2.setString(1, pv.getbabyName());
//						pstmt2.setString(2, pv.getbabyGender());
//						pstmt2.setString(3, pv.getaddress());
//						pstmt2.setString(4, pv.getstation());
//						pstmt2.executeUpdate();
//						returns = "회원 가입 성공 !";
//					}
//				}
//			} catch (Exception e) {
//				e.printStackTrace();
//			} finally {
//				if (pstmt2 != null)
//					try {
//						pstmt2.close();
//					} catch (SQLException ex) {
//					}
//				if (getConnection() != null)
//					try {
//						getConnection().close();
//					} catch (SQLException ex) {
//					}
//			}
//		} else
//			returns = "메롱부모님";
//		return returns;
//	}
//
//}