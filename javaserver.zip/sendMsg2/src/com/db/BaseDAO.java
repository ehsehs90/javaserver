package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BaseDAO {
	Da
}

	public static Connection getConnection() {

		// oracle 계정
		String jdbcUrl = "jdbc:oracle:thin:@70.12.115.54:1521:xe";
		String userId = "SCOTT";
		String userPw = "TIGER";
		Connection conn = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			conn = DriverManager.getConnection(jdbcUrl, userId, userPw);
			// System.out.println("연결성공, 호출성공");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;
	}

	public String register(BaseVO base) throws SQLException {

		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs = null;

		String returns = null;

		try {
			String sql = "SELECT ID FROM BASE WHERE ID = ?"; // APPUSERINFO
			pstmt = getConnection().prepareStatement(sql);
			pstmt.setString(1, base.getMemberID());
			rs = pstmt.executeQuery();

			System.out.println("id는 ? : @" + base.getMemberID());
			System.out.println("pw는 ? : @" + base.getMemberPW());
			System.out.println("name는 ? : @" + base.getMemberName());
			System.out.println("tel는 ? : @" + base.getMemberTel());
			System.out.println("date는 ? : @" + base.getRegisterDate());
			System.out.println("info는? : @" + base.getMemberinfo());

			if (base.getMemberID() == null || base.getMemberID().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = "회원 가입 실패! 아이디에 값을 입력해 주세요.";
			} else if (base.getMemberPW() == null || base.getMemberPW().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = "회원 가입 실패! 비밀번호에 값을 입력해 주세요.";
			} else if (base.getMemberName() == null || base.getMemberName().isEmpty() == true) {
				// System.out.println("dddddd");
				returns = "회원 가입 실패! 이름에 값을 입력해 주세요.";
			} else {
				if (rs.next()) {
					returns = "이미 존재하는 아이디 입니다.";
				} else {
					try {
						String sql2 = "INSERT INTO BASE VALUES(?,?,?,?)";
						pstmt2 = getConnection().prepareStatement(sql2);
						pstmt2.setString(1, base.getMemberID());
						pstmt2.setString(2, base.getMemberPW());
						pstmt2.setString(3, base.getMemberName());
						pstmt2.setString(4, base.getMemberTel());
						pstmt2.executeUpdate();

						returns = "회원 가입 성공 !";

					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						if (pstmt2 != null)
							try {
								pstmt2.close();
							} catch (SQLException ex) {
							}
						if (getConnection() != null)
							try {
								getConnection().close();
							} catch (SQLException ex) {
							}
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt2 != null)
				try {
					pstmt2.close();
				} catch (SQLException ex) {
				}
			return returns;
		}
	}

}